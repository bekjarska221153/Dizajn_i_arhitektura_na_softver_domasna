// Симулирани податоци за табелата
const allIssuersDataLast10Years = [
    { issuer: "ADIN", date: "2015-11-13", lastTransaction: 290, max: 290, min: 290, avgPrice: 290, change: "0.00%", quantity: 0 },
    { issuer: "ADIN", date: "2015-11-12", lastTransaction: 290, max: 290, min: 290, avgPrice: 290, change: "0.00%", quantity: 0 },
    { issuer: "ADIN", date: "2015-11-11", lastTransaction: 290, max: 290, min: 290, avgPrice: 290, change: "0.00%", quantity: 0 },
    { issuer: "ADIN", date: "2015-11-10", lastTransaction: 290, max: 290, min: 290, avgPrice: 290, change: "0.00%", quantity: 200 },
    { issuer: "ADIN", date: "2015-11-09", lastTransaction: 290, max: 290, min: 290, avgPrice: 290, change: "0.00%", quantity: 0 }
];

// Функција за прикажување податоци во табелата
function displayData(data) {
    const tableBody = document.getElementById("dataTable");
    tableBody.innerHTML = ""; // Исчисти ја табелата
    data.forEach(row => {
        const tr = document.createElement("tr");
        tr.innerHTML = `
      <td>${row.issuer}</td>
      <td>${row.date}</td>
      <td>${row.lastTransaction}</td>
      <td>${row.max}</td>
      <td>${row.min}</td>
      <td>${row.avgPrice}</td>
      <td>${row.change}</td>
      <td>${row.quantity}</td>
    `;
        tableBody.appendChild(tr);
    });
}

// Прикажи ги сите податоци при вчитување
displayData(allIssuersDataLast10Years);

// Филтер функција
function filterData() {
  const issuerCode = document.getElementById("issuerCode").value.toUpperCase();
  const dateFrom = document.getElementById("dateFrom").value;
  const dateTo = document.getElementById("dateTo").value;

  // AJAX повик до Flask API
  fetch(`/api/data?issuerCode=${issuerCode}&dateFrom=${dateFrom}&dateTo=${dateTo}`)
    .then(response => response.json())
    .then(data => {
      displayData(data);
    })
    .catch(error => console.error("Error fetching data:", error));
}


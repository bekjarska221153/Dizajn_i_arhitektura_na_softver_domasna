from flask import Flask, render_template, request, jsonify
import matplotlib.pyplot as plt
import pandas as pd
import io
import base64
import datetime

app = Flask(__name__)

# Примерни податоци за издавачи
all_issuers_data_last_10_years = [
    {"issuer": "ADIN", "date": "2015-11-13", "lastTransaction": 290, "max": 290, "min": 290, "avgPrice": 290, "change": "0.00%", "quantity": 0},
    {"issuer": "ADIN", "date": "2015-11-12", "lastTransaction": 290, "max": 290, "min": 290, "avgPrice": 290, "change": "0.00%", "quantity": 0},
    {"issuer": "ADIN", "date": "2015-11-11", "lastTransaction": 290, "max": 290, "min": 290, "avgPrice": 290, "change": "0.00%", "quantity": 0},
    {"issuer": "ADIN", "date": "2015-11-10", "lastTransaction": 290, "max": 290, "min": 290, "avgPrice": 290, "change": "0.00%", "quantity": 200},
    {"issuer": "ADIN", "date": "2015-11-09", "lastTransaction": 290, "max": 290, "min": 290, "avgPrice": 290, "change": "0.00%", "quantity": 0}
]

# Рута за прикажување на главната страница
@app.route('/')
def index():
    return render_template('index.html')

# API за враќање податоци
@app.route('/api/data', methods=['GET'])
def get_data():
    issuer_code = request.args.get('issuerCode', '').upper()
    date_from = request.args.get('dateFrom')
    date_to = request.args.get('dateTo')

    # Филтрирање податоци
    filtered_data = [
        row for row in all_issuers_data_last_10_years
        if (not issuer_code or row['issuer'].startswith(issuer_code)) and
           (not date_from or datetime.datetime.strptime(row['date'], '%Y-%m-%d') >= datetime.datetime.strptime(date_from, '%Y-%m-%d')) and
           (not date_to or datetime.datetime.strptime(row['date'], '%Y-%m-%d') <= datetime.datetime.strptime(date_to, '%Y-%m-%d'))
    ]

    return jsonify(filtered_data)

if __name__ == '__main__':
    app.run(debug=True)
@app.route('/analysis')
def analysis():
    return render_template('analysis.html')

@app.route('/api/analysis', methods=['GET'])
def generate_plot():
    issuer_code = request.args.get('issuerCode', '').upper()
    date_from = request.args.get('dateFrom')
    date_to = request.args.get('dateTo')

    # Подготовка на податоци
    df = pd.DataFrame(all_issuers_data_last_10_years)
    df['date'] = pd.to_datetime(df['date'])
    if issuer_code:
        df = df[df['issuer'] == issuer_code]
    if date_from:
        df = df[df['date'] >= pd.to_datetime(date_from)]
    if date_to:
        df = df[df['date'] <= pd.to_datetime(date_to)]

    # Генерирање на графикон
    plt.figure(figsize=(10, 5))
    plt.plot(df['date'], df['price'], label="Stock Price", color="blue")
    plt.title("Stock Price with Buy/Sell Signals")
    plt.xlabel("Date")
    plt.ylabel("Price")
    plt.legend()

    # Конвертирање на графиконот во base64
    img = io.BytesIO()
    plt.savefig(img, format='png')
    img.seek(0)
    graph_url = base64.b64encode(img.getvalue()).decode()

    return jsonify({"graph": f"data:image/png;base64,{graph_url}"})

if __name__ == '__main__':
    app.run(debug=True)